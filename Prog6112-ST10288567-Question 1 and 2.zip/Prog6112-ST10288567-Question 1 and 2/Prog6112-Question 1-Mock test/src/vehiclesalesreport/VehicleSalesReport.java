/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package vehiclesalesreport;

import java.util.Scanner;

/**
 * This program generates a vehicle sales report for different vehicle types 
 * over a period of three months. It collects sales data, displays a formatted
 * report, and provides a total sales summary with an award status.
 * 
 * @author Darsh Somayi
 */
public class VehicleSalesReport {
    public static void main(String[] args) {
        // Define the vehicle types and months for the report
        String[] vehicleTypes = {"SUV", "COUPE", "SEDAN", "VAN"}; // Array holding different vehicle types
        String[] months = {"January", "February", "March"};      // Array holding months for the report

        // Create a 2D array to store the sales data
        int[][] sales = new int[vehicleTypes.length][months.length]; // 2D array to store sales per vehicle per month

        // Input sales data from the user
        Scanner scanner = new Scanner(System.in); // Initialize the scanner for user input
        for (int i = 0; i < vehicleTypes.length; i++) { // Loop through each vehicle type
            for (int j = 0; j < months.length; j++) {   // Loop through each month
                // Prompt the user to enter sales data for the specific vehicle and month
                System.out.print("Enter sales for " + vehicleTypes[i] + " in " + months[j] + ": ");
                sales[i][j] = scanner.nextInt(); // Store the inputted sales value in the array
            }
        }

        // Display the formatted sales report
        System.out.println("\n--- Vehicle Sales Report ---");
        System.out.printf("%-10s %-10s %-10s %-10s %n", "Vehicle", "January", "February", "March"); // Header

        // Loop to print the sales data for each vehicle type
        for (int i = 0; i < vehicleTypes.length; i++) {
            System.out.printf("%-10s", vehicleTypes[i]); // Print the vehicle type
            for (int j = 0; j < months.length; j++) {
                System.out.printf("%-10d", sales[i][j]); // Print the sales data for each month
            }
            System.out.println(); // Move to the next line after each vehicle's data
        }

        // Calculate and display total sales for each vehicle type, along with its award status
        System.out.println("\n--- Total Sales and Status ---");
        for (int i = 0; i < vehicleTypes.length; i++) {
            int totalSales = 0; // Initialize total sales for each vehicle type
            for (int j = 0; j < months.length; j++) {
                totalSales += sales[i][j]; // Add sales for each month
            }

            // Determine the award status based on total sales (Gold if >= 100, otherwise Silver)
            String status = totalSales >= 100 ? "Gold" : "Silver";
            System.out.println(vehicleTypes[i] + " - Total Sales: " + totalSales + " - Status: " + status); // Output result
        }

        // Close the scanner object
        scanner.close();
    }
}

/* 
// Reference List
// Date: 17 September 2024
// Author: Darsh Somayi
// Sourced: Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.
*/
