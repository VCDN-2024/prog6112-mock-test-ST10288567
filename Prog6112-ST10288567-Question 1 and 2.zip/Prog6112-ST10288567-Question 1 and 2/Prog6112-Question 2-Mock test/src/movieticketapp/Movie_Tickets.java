/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package movieticketapp;

/**
 *
 * @author Darsh Somayi
 */



// Main class that handles user input and runs the program
import java.util.Scanner;

public class Movie_Tickets {

    public static void main(String[] args) {
        // Scanner object to take input from the user
        Scanner input = new Scanner(System.in);

        // Asking user to enter customer name
        System.out.print("Enter customer name: ");
        String customerName = input.nextLine();  // Reading the customer's name

        // Asking user to enter the movie title
        System.out.print("Enter movie title: ");
        String movieTitle = input.nextLine();    // Reading the movie title

        // Asking user to enter customer age
        System.out.print("Enter customer age: ");
        int customerAge = input.nextInt();       // Reading the customer's age

        // Asking user to enter the price of the movie in Rands
        System.out.print("Enter movie price in Rands: ");
        double moviePrice = input.nextDouble();  // Reading the movie price

        // Instantiate the TicketSales class with customer details and movie price
        TicketSales ticket = new TicketSales(customerName, movieTitle, customerAge, moviePrice);

        // Call the print_tickets method to display the ticket information
        ticket.print_tickets();

        // Close the scanner object to prevent resource leaks
        input.close();
    }
}


/* 
// Reference List
// Date: 17 September 2024
// Author: Darsh Somayi
// Sourced: Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.
*/
