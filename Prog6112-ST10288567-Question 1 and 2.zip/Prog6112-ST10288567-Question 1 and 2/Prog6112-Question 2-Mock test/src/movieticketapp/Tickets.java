/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package movieticketapp;

/**
 *
 * @author Darsh Somayi
 */

// Abstract class that implements the iTickets interface
public abstract class Tickets implements iTickets {
    // Protected variables to store customer information and movie details
    protected String customerName;
    protected String movieTitle;
    protected int customerAge;
    protected double moviePrice;

    // Constructor to initialize the variables
    public Tickets(String customerName, String movieTitle, int customerAge, double moviePrice) {
        this.customerName = customerName;
        this.movieTitle = movieTitle;
        this.customerAge = customerAge;
        this.moviePrice = moviePrice;
    }

    // Getter method for customer name
    public String getCustomerName() {
        return customerName;
    }

    // Getter method for movie title
    public String getMovieTitle() {
        return movieTitle;
    }

    // Getter method for customer age
    public int getCustomerAge() {
        return customerAge;
    }

    // Getter method for movie price
    public double getMoviePrice() {
        return moviePrice;
    }

    // Abstract method to print ticket, to be implemented in the subclass
    public abstract void print_tickets();
}


/* 
// Reference List
// Date: 17 September 2024
// Author: Darsh Somayi
// Sourced: Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.
*/
