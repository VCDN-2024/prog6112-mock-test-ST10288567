/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package movieticketapp;

/**
 *
 * @author Darsh Somayi
 */

// Interface to declare the method for printing tickets
public interface iTickets {
    // Method to print tickets
    public void print_tickets();
}


/* 
// Reference List
// Date: 17 September 2024
// Author: Darsh Somayi
// Sourced: Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.
*/
