/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package movieticketapp;

/**
 *
 * @author Darsh Somayi
 */


// Subclass of Tickets that implements the logic for ticket sales
public class TicketSales extends Tickets {

    // Constructor that calls the superclass constructor to initialize the variables
    public TicketSales(String customerName, String movieTitle, int customerAge, double moviePrice) {
        super(customerName, movieTitle, customerAge, moviePrice);
    }

    // Private method to calculate the discount based on customer age
    private double calculateDiscount() {
        // If the customer is 65 years or older, apply a 10% discount
        if (customerAge >= 65) {
            return moviePrice * 0.10;  // 10% discount
        }
        // No discount if customer is younger than 65
        return 0.0;
    }

    // Private method to calculate the final cost after applying the discount
    private double finalCost() {
        // Final cost is the movie price minus the discount
        return moviePrice - calculateDiscount();
    }

    // Overriding the print_tickets method from the iTickets interface
    @Override
    public void print_tickets() {
        // Printing the ticket details, including discount and final cost
        System.out.println("===== Movie Ticket =====");
        System.out.println("Customer Name: " + customerName);    // Display customer name
        System.out.println("Movie Title: " + movieTitle);        // Display movie title
        System.out.println("Price: R" + moviePrice);             // Display original movie price
        double discount = calculateDiscount();                   // Calculate discount
        System.out.println("Discount: R" + discount);            // Display discount amount
        System.out.println("Final Cost: R" + finalCost());       // Display final cost after discount
        System.out.println("========================");
    }
}


/* 
// Reference List
// Date: 17 September 2024
// Author: Darsh Somayi
// Sourced: Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.
*/
